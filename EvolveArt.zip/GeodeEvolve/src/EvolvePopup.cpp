#include "EvolvePopup.hpp"
#include <Geode/binding/EditorUI.hpp>
#include <Geode/binding/LevelEditorLayer.hpp>
#include <Geode/utils/file.hpp>

using namespace geode::prelude;

EvolvePopup* EvolvePopup::create() {
    auto ret = new EvolvePopup();
    if (ret->initAnchored(360.f, 220.f, "EvolveArt.png"_spr)) {
        ret->autorelease();
        return ret;
    }
    delete ret;
    return nullptr;
}

bool EvolvePopup::setup() {
    setTitle("EvolveArt");

    auto winSize = m_mainLayer->getContentSize();

    m_imageLabel = CCLabelBMFont::create("No image selected", "chatFont.fnt");
    m_imageLabel->setScale(0.6f);
    m_imageLabel->setPosition({winSize.width / 2, winSize.height - 55});
    m_mainLayer->addChild(m_imageLabel);

    auto chooseBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("Choose Image"),
        this, menu_selector(EvolvePopup::onChooseImage)
    );

    m_startBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("Start"),
        this, menu_selector(EvolvePopup::onStartPause)
    );

    auto stopBtn = CCMenuItemSpriteExtra::create(
        ButtonSprite::create("Stop", "goldFont.fnt", "GJ_button_05.png"),
        this, menu_selector(EvolvePopup::onStop)
    );

    auto menu = CCMenu::create();
    menu->addChild(chooseBtn);
    menu->addChild(m_startBtn);
    menu->addChild(stopBtn);
    menu->setLayout(RowLayout::create()->setGap(12.f));
    menu->setContentSize({320.f, 40.f});
    menu->updateLayout();
    menu->setPosition({winSize.width / 2, winSize.height - 100});
    m_mainLayer->addChild(menu);

    m_statusLabel = CCLabelBMFont::create("Pick an image to begin.", "chatFont.fnt");
    m_statusLabel->setScale(0.6f);
    m_statusLabel->setPosition({winSize.width / 2, winSize.height - 140});
    m_mainLayer->addChild(m_statusLabel);

    auto hint = CCLabelBMFont::create(
        "Runs live while this popup is open. Adjust\npopulation/budget in the mod's settings.",
        "chatFont.fnt"
    );
    hint->setScale(0.45f);
    hint->setAlignment(kCCTextAlignmentCenter);
    hint->setPosition({winSize.width / 2, 35});
    m_mainLayer->addChild(hint);

    schedule(schedule_selector(EvolvePopup::step), 0.05f); // ~20 ticks/sec
    return true;
}

void EvolvePopup::onChooseImage(CCObject*) {
    auto filter = file::FilePickOptions::Filter{
        .description = "Images",
        .files = {"*.png", "*.jpg", "*.jpeg"}
    };
    file::pick(file::PickMode::OpenFile, file::FilePickOptions{std::nullopt, {filter}})
        .listen([this](Result<std::filesystem::path>* result) {
            if (!result || result->isErr()) return;
            m_imagePath = result->unwrap().string();

            int blocks = Mod::get()->getSettingValue<int64_t>("canvas-blocks-wide");
            bool ok = m_engine.loadTarget(m_imagePath, blocks, blocks, 40, 40, 60);
            if (!ok) {
                m_statusLabel->setString("Couldn't read that image file.");
                return;
            }
            m_engine.setPopulationSize((int)Mod::get()->getSettingValue<int64_t>("population-size"));
            m_engine.setMaxObjects((int)Mod::get()->getSettingValue<int64_t>("max-objects"));
            m_imageLabel->setString(std::filesystem::path(m_imagePath).filename().string().c_str());
            m_hasStarted = false;
            m_statusLabel->setString("Ready. Press Start.");
        });
}

void EvolvePopup::onStartPause(CCObject*) {
    if (m_imagePath.empty()) {
        m_statusLabel->setString("Choose an image first.");
        return;
    }

    if (!m_hasStarted) {
        auto* editorUI = EditorUI::get();
        if (!editorUI) {
            m_statusLabel->setString("Open a level in the editor first!");
            return;
        }
        // Places the mosaic starting a little right of the spawn point so
        // it doesn't overlap the start position; tune originX/Y/blockSize
        // to taste, or expose them as settings later.
        m_builder = std::make_unique<LevelBuilder>(editorUI, 150.f, 105.f, 30.f);
        m_builder->setupColorPalette();
        m_hasStarted = true;
    }

    m_running = !m_running;
    m_startBtn->setSprite(ButtonSprite::create(m_running ? "Pause" : "Resume"));
}

void EvolvePopup::onStop(CCObject*) {
    m_running = false;
    m_hasStarted = false;
    m_startBtn->setSprite(ButtonSprite::create("Start"));
    m_statusLabel->setString("Stopped. Choose an image to start a new build.");
}

void EvolvePopup::step(float) {
    if (!m_running || !m_builder) return;

    int generationsPerTick = (int)Mod::get()->getSettingValue<int64_t>("generations-per-tick");
    std::vector<Gene> accepted;
    m_engine.step(generationsPerTick, accepted);

    for (auto& gene : accepted) {
        m_builder->place(gene);
    }

    if (m_engine.finished()) {
        m_running = false;
        m_startBtn->setSprite(ButtonSprite::create("Start"));
    }

    refreshLabel();
}

void EvolvePopup::refreshLabel() {
    if (!m_statusLabel) return;
    double init = m_engine.initialError();
    double cur = m_engine.currentError();
    double pct = init > 0 ? std::clamp(100.0 * (1.0 - cur / init), 0.0, 100.0) : 0.0;

    m_statusLabel->setString(fmt::format(
        "Objects: {}  |  Similarity: {:.1f}%{}",
        m_engine.objectsPlaced(), pct, m_running ? "" : "  (paused)"
    ).c_str());
}

#pragma once
#include <Geode/Geode.hpp>
#include <Geode/ui/Popup.hpp>
#include "EvolutionEngine.hpp"
#include "LevelBuilder.hpp"

using namespace geode::prelude;

class EditorUI;

class EvolvePopup : public geode::Popup<> {
protected:
    bool setup() override;
    void onChooseImage(CCObject*);
    void onStartPause(CCObject*);
    void onStop(CCObject*);
    void step(float dt);
    void refreshLabel();

    EvolutionEngine m_engine;
    std::unique_ptr<LevelBuilder> m_builder;
    std::string m_imagePath;
    bool m_running = false;
    bool m_hasStarted = false;

    CCLabelBMFont* m_statusLabel = nullptr;
    CCLabelBMFont* m_imageLabel = nullptr;
    CCMenuItemSpriteExtra* m_startBtn = nullptr;

public:
    static EvolvePopup* create();
};
